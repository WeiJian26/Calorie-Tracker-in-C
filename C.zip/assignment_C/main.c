#include <stdio.h>
#include <stdlib.h>
int CalBMI(float inweight,float inhight,float ingender);
void CALBMR(float inhight,float inweight,float inage,float ingender);

int main()
{
    float weight,hight,age,gender;
    CalBMI(weight,hight,gender);
    CALBMR(weight,hight,age,gender);
    return 0;
}
int CalBMI(float inweight,float inhight,float ingender)
{
    float BMI,IBW;
    printf("Enter your weight and hight\n");
    printf("your weight[kg] : \n ");
    scanf("%f",&inweight);
    printf("your hight[m] : \n");
    scanf("%f",&inhight);
    BMI = inweight /(inhight*inhight);
    printf("your BMI : \n",BMI);

    if (BMI <18.4)
        {
        printf("underweight %.2f\n",BMI);
        printf("Enter your gender \n");
        printf("[1]Male or [2]female\n");
        scanf("%f",&ingender);
            if ( ingender ==1)
            {
                IBW = 50 + (2.3 * ((inhight*100)-152.4)*0.3937);
                printf(" your ideal body weight is %.2f kg",IBW);
            }
            else if ( ingender ==2)
            {
                IBW = 45.5+(2.3 *((inhight*100)-152.4)*0.3937);
                printf(" your ideal body weight is %.2f kg",IBW);
            }
        }
    else if (BMI >=18.5 ||BMI <=24.9)
    {
        printf("normal weight %.2f\n",BMI);
    }
    else if (BMI >= 25 || BMI <=29.9)
    {
        printf("Overweight %2.f\n",BMI);
        printf("Enter your gender \n");
        printf("[1]Male or [2]female\n");
        scanf("%f",&ingender);
            if ( ingender ==1)
            {
                IBW = 50 + (2.3 * (inhight-152.4)*0.3937);
                printf(" your ideal body weight is %.2f kg",IBW);
            }
            else if ( ingender ==2)
            {
                IBW = 45.5+(2.3 *(inhight-152.4)*0.3937);
                printf(" your ideal body weight is %.2f kg",IBW);
            }
    }
    else if(BMI>=30)
    {
        printf("obesity %.2f\n",BMI);
        printf("Enter your gender \n");
        printf("[1]Male or [2]female\n");
        scanf("%f",&ingender);
            if ( ingender ==1)
            {
                IBW = 50 + (2.3 * (inhight-152.4)*0.3937);
                printf("your ideal body weight is %.2f kg",IBW);
            }
            else if ( ingender ==2)
            {
                IBW = 45.5+(2.3 *(inhight-152.4)*0.3937);
                printf("your ideal body weight is %.2f kg",IBW);
            }

    }
    return main;

}
void CALBMR(float inweight,float inhight,float inage,float ingender)
{

        float BMR;

        printf("\nactivity daily\n");
        printf("(1)Sedentary (little or no exercise)\n");
        printf("(2)lightly active (light exercise/ sports 1-3 days/week)\n");
        printf("(3)moderately active (moderate exercise / sports 3-5 days/week)\n");
        printf("(4)very active (hard exercise/ sports 6-7 days a week )\n");
        printf("\nEnter your age \n");
        scanf ("%f",&inage);
        BMR = 66+(13.7*(inweight*1000))+(5*(inhight*100))-(6.8*inage);
        printf("BMR : %.2f",BMR);
}
